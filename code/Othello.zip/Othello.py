from GUI import *
from State import *
from Ai import *


class Othello:
    def __init__(self):
        self.gui = None
        self.ai = None
        self.activePlayer = True
        self.ended = False
        self.currentBoard = State()
        self.currentBoard.setBoardConfig(
            [
                [0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0],
                [0,0,0,-1,1,0,0,0],
                [0,0,0,1,-1,0,0,0],
                [0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0],
                [0,0,0,0,0,0,0,0]
            ]
        )
        self.currentBoard.findPossibleMoves(self.activePlayer)

    def setup(self, ai, gui):
        self.ai = ai
        self.gui = gui

    def getActivePlayer(self):
        return self.activePlayer

    def setActivePlayer(self, player):
        self.activePlayer = player
        if not player:
            self.ai.launch()

    def getCurrentBoard(self):
        return self.currentBoard

    def getEnded(self):
        return self.ended

    def move(self, i, j, player):
        chess = 1 if player else -1
        newBoard = self.currentBoard.flipChess(i, j, player)
        self.currentBoard = State()
        self.currentBoard.setBoardConfig(newBoard)
        self.currentBoard.findPossibleMoves(not self.activePlayer)

        if self.currentBoard.getPossibleNextMove():
            print(str("W" if self.activePlayer else "B")+", "+str(len(self.currentBoard.getPossibleNextMove())))
            print(self.currentBoard.getPossibleNextMove())
            self.activePlayer = not self.activePlayer
            self.gui.updateGUI()
            self.activePlayer = not self.activePlayer
            self.setActivePlayer(not self.activePlayer)
        else:
            full = True
            for i in range(0, 8):
                for j in range(0, 8):
                    if self.currentBoard.getBoardConfig()[i][j] == 0:
                        full = False
                        break
            if full:
                self.ended = True
                self.gui.updateGUI()
            else:
                self.currentBoard.findPossibleMoves(self.activePlayer)
                if not self.currentBoard.getPossibleNextMove():
                    self.ended = True
                    self.gui.updateGUI()
                else:
                    # Keep GUI enabled for human / wake AI again
                    print("skipped")
                    self.gui.updateGUI()
                    self.setActivePlayer(self.activePlayer)


if __name__ == "__main__":
    ai = AI()
    game = Othello()
    gui = GUI()
    ai.setup(game)
    game.setup(ai, gui)

    gui.start(game)