from State import *
from Othello import *
from GUI import *

class AI:
    def __init__(self):
        self.game = None
        self.maxDepth = 3

    def setup(self, game):
        self.game = game

    # Wake up the AI to analyse the current game configuration and make a move
    def launch(self):
        state = self.game.getCurrentBoard()
        move = self.alphaBetaSearch(state)
        self.game.move(move[0], move[1], False)

    # Find minimum valued step for the AI
    def alphaBetaSearch(self, state):
        # Create a mapping of move -> score
        scoreMove = {}
        for move in state.getPossibleNextMove():
            scoreMove[move] = 0
        # Do the searching
        v = self.min(state, -float('inf'), float('inf'), scoreMove, 0)
        # Find the move with minimum score
        minMove = min(scoreMove, key=scoreMove.get)
        for m in scoreMove:
            print(str(m) + ': ' + str(scoreMove[m]))
        print(v, minMove, scoreMove[minMove])
        return minMove

    def max(self, state, a, b, scoreMove, d):
        state.findPossibleMoves(True)
        possibleNextMoves = state.getPossibleNextMove()
        if len(possibleNextMoves) == 0 or d > self.maxDepth:
            return state.score
        v = -float('inf')
        for move in possibleNextMoves:
            nextConfig = state.flipChess(move[0], move[1], True)
            nextState = State()
            nextState.setBoardConfig(nextConfig)
            v = max(v, self.min(nextState, a, b, scoreMove, d+1))
            if v >= b:
                return v
            a = max(a, v)
        return v

    def min(self, state, a, b, scoreMove, d):
        possibleNextMoves = state.getPossibleNextMove()
        if len(possibleNextMoves) == 0 or d > self.maxDepth:
            return state.score
        v = float('inf')
        for move in possibleNextMoves:
            nextConfig = state.flipChess(move[0], move[1], False)
            nextState = State()
            nextState.setBoardConfig(nextConfig)
            v = min(v, self.max(nextState, a, b, scoreMove, d+1))
            if v <= a:
                if d == 0 and move in scoreMove:
                    scoreMove[move] = v
                return v
            b = min(b, v)
            if d == 0 and move in scoreMove:
                scoreMove[move] = v
        return v
