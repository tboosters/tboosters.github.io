# GUI of the Othello game
from Othello import Othello
import tkinter


class GUI:
    def __init__(self):
        self.game = None
        self.canvasDim = 400
        self.squareWidth = self.canvasDim/8

        self.root = tkinter.Tk()
        self.initRoot()
        self.initMenu()

        self.boardCanvas = tkinter.Canvas(self.root, height=self.canvasDim, width=self.canvasDim,
                                        bg="#008855")
        self.drawBoard()
        self.boardCanvas.pack(pady="20")

        self.blackCountCanvas = tkinter.Canvas(self.root, height=self.canvasDim/4, width=self.canvasDim/4,
                                               bg="#000000", highlightthickness=0)
        self.blackCountText = self.blackCountCanvas.create_text(self.canvasDim/8,self.canvasDim/12,
                                                                font="Consolas 15 bold", fill="#FFFFFF",
                                                                text="0")
        self.whiteCountCanvas = tkinter.Canvas(self.root, height=self.canvasDim/4, width=self.canvasDim/4,
                                               bg="#FFFFFF", highlightthickness=0)
        self.whiteCountText = self.whiteCountCanvas.create_text(self.canvasDim/8,self.canvasDim/12,
                                                                font="Consolas 15 bold", fill="#000000",
                                                                text="0")
        self.blackCountCanvas.pack(padx="110", pady="20", side="left")
        self.whiteCountCanvas.pack(padx="20", pady="20", side="left")

    def start(self, game):
        self.game = game
        self.drawChess()
        self.drawCounts()
        self.drawCurrentPlayer()
        self.root.mainloop()

    def restart(self):
        ai = self.game.ai
        self.game = Othello()
        self.game.setup(ai, self)
        ai.setup(self.game)

        self.updateGUI()

    def initRoot(self):
        self.root.config(background="#A5814A")
        self.root.title("Othello")
        self.root.geometry("550x550")
        self.root.resizable(0, 0)

    def initMenu(self):
        menuBar = tkinter.Menu(self.root)
        menuBar.add_command(label="Restart", command=self.restart)
        menuBar.add_command(label="Quit", command=self.root.quit)
        self.root.config(menu=menuBar)

    def initCountCanvas(self):
        self.blackCountCanvas.create_text()

    def makeMove(self, event):
        x, y = int((event.x+2) / self.squareWidth), int((event.y+2) / self.squareWidth)
        if self.game.getActivePlayer() and \
                        (y,x) in self.game.getCurrentBoard().getPossibleNextMove():
            print("("+str(y)+", "+str(x)+")")
            self.game.move(y, x, self.game.getActivePlayer())

    def updateGUI(self):
        self.boardCanvas.delete("all")
        self.drawBoard()
        self.drawChess()
        self.drawCounts()
        self.drawCurrentPlayer()
        if self.game.getEnded():
            self.endGame()
        self.root.update()

    def drawBoard(self):
        for i in range(0, 8):
            for j in range(0, 8):
                objID = self.boardCanvas.create_rectangle(j * self.squareWidth, i * self.squareWidth,
                                                          (j+1) * self.squareWidth + 2, (i+1) * self.squareWidth + 2, outline="white")
                if (i+j) % 2 == 0:
                    self.boardCanvas.itemconfig(objID, fill="#075e3d")
                else:
                    self.boardCanvas.itemconfig(objID, fill="#008855")
                self.boardCanvas.tag_bind(objID, "<Button-1>", self.makeMove)

    # Draw chess on board according to the current configuration
    def drawChess(self):
        for y, row in enumerate(self.game.getCurrentBoard().getBoardConfig()):
            for x, state in enumerate(row):
                if state == 1:
                   self.boardCanvas.create_oval(
                        x*self.squareWidth + self.squareWidth/8,
                        y*self.squareWidth + self.squareWidth/8,
                        (x+1)*self.squareWidth - self.squareWidth/8,
                        (y+1)*self.squareWidth - self.squareWidth/8,
                        fill="#000000"
                   )
                elif state == -1:
                    self.boardCanvas.create_oval(
                        x*self.squareWidth + self.squareWidth/8,
                        y*self.squareWidth + self.squareWidth/8,
                        (x+1)*self.squareWidth - self.squareWidth/8,
                        (y+1)*self.squareWidth - self.squareWidth/8,
                        fill="#FFFFFF"
                    )
                elif (y,x) in self.game.getCurrentBoard().getPossibleNextMove():
                    mark = self.boardCanvas.create_text(
                        x*self.squareWidth + self.squareWidth/2,
                        y*self.squareWidth + self.squareWidth/2,
                        fill="yellow",
                        font="Consolas 15 bold",
                        text="x"
                    )
                    self.boardCanvas.tag_bind(mark, "<Button-1>", self.makeMove)

    # Draw chess counts for both sides on the GUI
    def drawCounts(self):
        counts = self.game.getCurrentBoard().getCounts()
        self.blackCountCanvas.itemconfigure(self.blackCountText, text=str(counts[0]))
        self.whiteCountCanvas.itemconfigure(self.whiteCountText, text=str(counts[1]))

    def drawCurrentPlayer(self):
        if self.game.getActivePlayer():
            self.blackCountCanvas.configure(highlightbackground="yellow", highlightthickness=3)
            self.whiteCountCanvas.configure(highlightthickness="0")
        else:
            self.whiteCountCanvas.configure(highlightbackground="blue", highlightthickness=3)
            self.blackCountCanvas.configure(highlightthickness="0")

    def endGame(self):
        finalCounts = self.game.getCurrentBoard().getCounts()
        if finalCounts[0] > finalCounts[1]:
            tkinter.messagebox.showinfo("Game Ended", "Black Wins!")
        elif finalCounts[1] > finalCounts[0]:
            tkinter.messagebox.showinfo("Game Ended", "White Wins!")
        else:
            tkinter.messagebox.showinfo("Game Ended", "It's a draw!")