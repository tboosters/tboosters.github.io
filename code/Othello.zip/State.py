import copy

class State:

    def __init__(self):
        self.possibleNextMove = set()
        self.boardConfig = []
        self.nBlack = 0
        self.nWhite = 0
        for i in range(0, 8):
            new = [0]*8
            self.boardConfig.append(new)
        self.score = 0

    def setPossibleMoves(self, moves):
        self.possibleNextMove = moves

    def getPossibleNextMove(self):
        return self.possibleNextMove

    def setBoardConfig(self, config):
        self.boardConfig = config
        self.nBlack = self.countBlack()
        self.nWhite = self.countWhite()
        self.findPossibleMoves(False)
        self.score = self.evaluate()

    def setBoardChess(self, i, j, state):
        self.boardConfig[i][j] = state
        self.nBlack = self.countBlack()
        self.nWhite = self.countWhite()

    def getBoardConfig(self):
        return self.boardConfig

    def getCounts(self):
        return (self.nBlack, self.nWhite)

    def findPossibleMoves(self, player):
        self.possibleNextMove.clear()
        for i in range(0, 8):
            for j in range(0, 8):
                if self.boardConfig[i][j] == 0:
                    self.isValidMove(i, j, player)

    # Check if board[i][j] on 8 directions will be a valid move for player
    def isValidMove(self, i, j, player):
        return self.exploreDir(lambda l:(l-1), lambda l:(l-1), i-1, j-1, i, j, player) or \
            self.exploreDir(lambda l:(l-1), lambda l:(l), i-1, j, i, j, player) or \
            self.exploreDir(lambda l:(l-1), lambda l:(l+1), i-1, j+1, i, j, player) or \
            self.exploreDir(lambda l:(l), lambda l:(l-1), i, j-1, i, j, player) or \
            self.exploreDir(lambda l:(l), lambda l:(l+1), i, j+1, i, j, player) or \
            self.exploreDir(lambda l:(l+1), lambda l:(l-1), i+1, j-1, i, j, player) or \
            self.exploreDir(lambda l:(l+1), lambda l:(l), i+1, j, i, j, player) or \
            self.exploreDir(lambda l:(l+1), lambda l:(l+1), i+1, j+1, i, j, player)

    # Check on particular direction if board[i][j] will be valid move for player
    def exploreDir(self, funcY, funcX, y, x, i, j, player):
        chess = 1 if player else -1
        while -1 < funcX(x) < 8 and -1 < funcY(y) < 8 and self.boardConfig[y][x] == -chess:
            x = funcX(x)
            y = funcY(y)
            if self.boardConfig[y][x] == chess:
                self.possibleNextMove.add((i,j))
                return True
        return False

    # Flip chess on board according to move by player at board[i][j], returns copy of board after flipping
    def flipChess(self, i, j, player):
        result = copy.deepcopy(self.boardConfig)
        chess = 1 if player else -1
        result[i][j] = chess
        result = self.flipDir(lambda l:(l-1), lambda l:(l-1), i-1, j-1, chess, result)
        result = self.flipDir(lambda l:(l-1), lambda l:(l), i-1, j, chess, result)
        result = self.flipDir(lambda l:(l-1), lambda l:(l+1), i-1, j+1, chess, result)
        result = self.flipDir(lambda l:(l), lambda l:(l-1), i, j-1, chess, result)
        result = self.flipDir(lambda l:(l), lambda l:(l+1), i, j+1, chess, result)
        result = self.flipDir(lambda l:(l+1), lambda l:(l-1), i+1, j-1, chess, result)
        result = self.flipDir(lambda l:(l+1), lambda l:(l), i+1, j, chess, result)
        result = self.flipDir(lambda l:(l+1), lambda l:(l+1), i+1, j+1, chess, result)
        return result

    # Flip chess on particular direction
    def flipDir(self, funcY, funcX, y, x, chess, result):
        originalConfig = copy.deepcopy(result)
        while -1 < funcX(x) < 8 and -1 < funcY(y) < 8 and self.boardConfig[y][x] == -chess:
            result[y][x] = chess
            x = funcX(x)
            y = funcY(y)
            if result[y][x] == chess:
                return result
            elif result[y][x] == 0:
                return originalConfig
        return originalConfig

    def countBlack(self):
        count = 0
        for i in range(0, 8):
            for j in range(0, 8):
                if self.boardConfig[i][j] == 1:
                    count += 1
        return count

    def countWhite(self):
        count = 0
        for i in range(0, 8):
            for j in range(0, 8):
                if self.boardConfig[i][j] == -1:
                    count += 1
        return count

    def evaluate(self):
        score = 0
        score += self.calcP()
        score += self.calcC()
        score += self.calcI()
        score += self.calcM()
        return score

    def calcP(self):
        b, w = self.nBlack, self.nWhite
        if b > w:
            return 50 * b/(b+w)
        elif b < w:
            return 50 * -w/(b+w)
        else:
            return 0

    def calcC(self):
        config = self.getBoardConfig()
        return 25 * (config[0][0] + config[0][7] + config[7][0] + config[7][7])

    def calcI(self):
        return 12.5 * \
               (self.wMinusB(0, 0) + self.wMinusB(0, 7) + self.wMinusB(7, 0) + self.wMinusB(7, 7))

    def wMinusB(self, i, j):
        config = self.boardConfig
        if config[i][j] == 0:
            if i == 0 and j == 0:
                return -config[0][1] - config[1][0] - config[1][1]
            if i == 0 and j == 7:
                return -config[0][6] - config[1][6] - config[1][7]
            if i == 7 and j == 0:
                return -config[6][0] - config[6][1] - config[7][1]
            if i == 7 and j == 7:
                return -config[6][6] - config[6][7] - config[7][6]
        else:
            return 0

    def calcM(self):
        original = copy.deepcopy(self.getPossibleNextMove())
        self.findPossibleMoves(True)
        w = len(original)
        b = len(self.getPossibleNextMove())
        self.setPossibleMoves(original)
        if b > w:
            return b/(b+w)*150
        elif b < w:
            return -w/(b+w)*150
        else:
            return 0